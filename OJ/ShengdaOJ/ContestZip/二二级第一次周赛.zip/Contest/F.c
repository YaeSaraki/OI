#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int prime(long long int n);
int diandao(long long int n);

int main()
{
    long long int n;
    scanf("%lld", &n);
    if (prime(n) == 1)
    {
        if (diandao(n) == n || (n % 10 == 0 && n / 10 == diandao(n)))
            printf("Yes");
        else
            printf("No");
    }
    else
        printf("No");
    return 0;
}

int prime(long long int n)
{
    if (n == 1 || n == 0)
        return 0;
    else if (n == 2)
        return 1;
        
    else
    {
        for (int i = 2; i < n; i++)
        {
            if (n % i == 0)
                return 0;
        }
        return 1;
    }
}

int diandao(long long int n)
{
    long long int m, d = 0;
    while (n)
    {
        m = n % 10;
        n /= 10;
        d = d * 10 + m;
    }
    return d;
}