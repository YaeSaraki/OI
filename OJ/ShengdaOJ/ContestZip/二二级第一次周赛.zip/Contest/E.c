#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    long long int m, sum;
    while (scanf("%lld", &m) != EOF)
    {
        sum = ((1 + m) * m) / 2;
        printf("%lld\n", sum);
    }
    return 0;
}