#include <stdio.h>

int main()
{
    int n;
    scanf("%d", &n);
    if (n > 10)
        printf("-1");
    else if (n == 2)
    {
        printf("10");
    }
    else if (n == 1)
        printf("1");
    else if (n == 0)
        printf("-1");
    else
    {
        printf("10");
        int m = 2;
        for (int i = 1; i <= n - 2; i++)
        {
            printf("%d", m);
            m++;
        }
    }
    return 0;
}