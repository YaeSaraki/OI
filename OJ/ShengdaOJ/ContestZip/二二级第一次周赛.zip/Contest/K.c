#include <stdio.h>

int main()
{
    int m, n;
    scanf("%d%d", &m, &n);
    int a[3 * m][n] = {0};
    for (int i = 0, i < 3 * m; i++)
        for (int j = 0; j < n; j++)
        {
            int o =3*m/2
        }
}