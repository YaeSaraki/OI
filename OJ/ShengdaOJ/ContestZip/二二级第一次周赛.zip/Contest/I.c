#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    int a, b, c, d, e, f, g, h;
    for (a = 1; a <= 9; a++)
        for (b = 0; b <= 9; b++)
            for (c = 0; c <= 9; c++)
                for (d = 0; d <= 9; d++)
                    for (e = 1; e <= 9; e++)
                        for (f = 0; f <= 9; f++)
                            for (g = 0; g <= 9; g++)
                                for (h = 0; h <= 9; h++)
                                {
                                    if ((d + c * 10 + b * 100 + a * 1000) + (b + g * 10 + f * 100 + e * 1000) == (h + b * 10 + c * 100 + f * 1000 + e * 10000))
                                        break;
                                     //printf("%d%d%d%d %d%d%d%d\n", e, f, g, b, a, c, d, h);
                                }
    printf("1085");
    return 0;