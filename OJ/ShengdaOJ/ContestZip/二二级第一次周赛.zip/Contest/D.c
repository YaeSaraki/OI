#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    int n, flag = 0;
    long long int sum = 1;
    scanf("%d", &n);
    for (int i = 1; i <= n;)
    {
        sum = sum * i;
        if (sum > 100000)
        {
            sum %= 100000;
            flag = 1;
        }
        i += 2;
    }
    if (n == 0)
        sum = 0;
    while (flag == 1)
    {
        if (flag == 1 && sum <= 9)
        {
            printf("0000");
            flag = 0;
        }
        if (flag == 1 && sum <= 99)
        {
            printf("000");
            flag = 0;
        }
        if (flag == 1 && sum <= 999)
        {
            printf("00");
            flag = 0;
        }
        if (flag == 1 && sum <= 9999)
        {
            printf("0");
            flag = 0;
        }
    }

    printf("%lld", sum);
    return 0;
}