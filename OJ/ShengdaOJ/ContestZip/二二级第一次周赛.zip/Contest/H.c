#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    char a[10001] = {0};
    int g = 0, p = 0, l = 0, t = 0;

    gets(a);
    int len = strlen(a);

    for (int i = 0; i < len; i++)
    {
        if (a[i] == 'G'||a[i] == 'g')
            g++;
        if (a[i] == 'P'||a[i] == 'p')
            p++;
        if (a[i] == 'L'||a[i] == 'l')
            l++;
        if (a[i] == 'T'||a[i] == 't')
            t++;
    }

    for (int i = 1;; i++)
    {
        if (
        {
            printf("G");
            g--;
        }
        if (p)
        {
            printf("P");
            p--;
        }
        if (l)
        {
            printf("L");
            l--;
        }
        if (t)
        {
            printf("T");
            t--;
        }
        if (g + p + l + t == 0)
            break;
    }
    return 0;
}