#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int prime(long long int n);

int main()
{
    long long int n, min = 0, sum1, sum2, m;
    scanf("%lld", &n);
    for (int i = 1; i <= n; i++)
    {
        if (i % 2 != 0)
        {
            scanf("%lld", &m);
            if (prime(m) == 1)
                sum1 += m;
        }
        else
        {
            scanf("%lld", &m);
            if (prime(m) == 1)
                sum2 += m;
        }
    }
    if (sum1 == sum2)
        printf("a dead heat！！");
    else if (sum1 < sum2)
        printf("ZH");
    else
        printf("ZjX");
    return 0;
}

int prime(long long int n)
{
    if (n == 1)
        return 0;
    if (n == 0)
        return 0;
    else if (n == 2)
        return 1;
    else
    {
        for (int i = 2; i < n; i++)
        {
            if (n % i == 0)
                return 0;
        }
        return 1;
    }
}