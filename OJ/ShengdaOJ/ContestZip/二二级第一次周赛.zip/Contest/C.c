#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    long long int m, n, max, min;
    scanf("%lld%lld", &m, &n);
    max = m;
    max = (m > n) ? m : n;
    for (int i = 2; i < max; i++)
    {
        if (m % i == 0 && n % i == 0)
        {
            min = i;
            break;
        }
    }
    long long int len = 0;
    long long int sum = m * n;

    printf("%lld ", sum);
    while (sum)
    {
        sum /= 10;
        len++;
    }
    if (len == 0)
        len++;
    printf("%lld", len);
    return 0;
}