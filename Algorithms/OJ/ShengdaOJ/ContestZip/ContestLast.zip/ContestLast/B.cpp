#include <bits/stdc++.h>
using namespace std;

int main() {
  int T;
  while (cin >> T, T != '0') {
    if (T % 2 == 0)
      cout << "wyz\n";
    else
      cout << "zjx\n";
  }
  return 0;
}