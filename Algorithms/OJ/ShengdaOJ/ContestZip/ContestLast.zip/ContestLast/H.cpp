#include <iostream>
#include <string>
using namespace std;

int main() {
  string a;
  string b;
  int *a = strstr(a, b);
}