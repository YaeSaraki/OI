#include <math.h>

#include <iostream>

int main() {  

}
